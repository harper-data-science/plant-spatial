# Input code for Data Set 3
# This statement assumes that a working directory has been set with setwd()
# as described in Section 2.4.2

data.Set3 <- read.csv("set3\\set3data.csv", header = TRUE)

# Weather data
wthr.data <- read.csv("set3\\Set3Weather.csv", header = TRUE)